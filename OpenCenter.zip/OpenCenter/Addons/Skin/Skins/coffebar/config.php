<?php
return array(
	'name' => '咖啡吧'
);