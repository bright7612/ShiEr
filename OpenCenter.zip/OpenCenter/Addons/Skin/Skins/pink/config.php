<?php
return array(
	'name' => '魅力绚紫',
    'sort' => '5'
);